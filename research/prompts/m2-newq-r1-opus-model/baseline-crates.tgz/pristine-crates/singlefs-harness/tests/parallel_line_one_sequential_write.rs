//! 里程碑「第二个事务」并行线一（一个文件跨多个单元）的**写路径**验收，只做写这一半，读那一半不在这一轮。
//!
//! 两件事：
//! ① 一次写请求按切分纪律切成若干一单元事务（D16（发布语义） 已定项 5 末段、D23（journal 的角色与格式） 已定项 7、
//!    C310（事务切分纪律与记录数口径打架） 2026-09-16 用户定案），切出一个事务的那一档与覆盖写走同一条发布路径、写出的字节一个不变；
//! ② 切出不止一个事务时，多单元写要的两条条款仓里还没定 ⇒ 在任何落盘动作之前拒绝，盘上逐字节不变
//!    （`DiskSnapshot`：两盘四个系统配置槽的原样字节、根环里全部自证过的根、录制流步数），分配器也一个记录都没动。

mod common;

use common::{
    build_pool, disk_snapshot, parameters, BuiltPool, DiskSnapshot, FIXED_WRITE_TIME_SECONDS,
};
use singlefs_core::address::InstanceGeneration;
use singlefs_core::transaction::{
    publish_overwrite, publish_sequential_write, FirstFile, PoolWriter, PublishError,
    TransactionOutput, UndecidedClauseBlockingMoreThanOneDataUnit,
};
use singlefs_core::unit::data_unit_payload_capacity;
use singlefs_core::write_request_split::{
    data_unit_count_of_a_sequential_write, split_sequential_write_into_one_unit_transactions,
};
use singlefs_harness::RetainedOperation;

/// 一份可复现的内容：长度由调用点给，字节只随下标走。
fn content_of(length_in_bytes: usize) -> Vec<u8> {
    (0..length_in_bytes)
        .map(|index| u8::try_from((index * 7 + 3) % 253).expect("小于 256"))
        .collect()
}

/// 这份内容要几个数据单元：长度按净荷容量向上取整。
fn data_units_for(length_in_bytes: usize) -> u64 {
    data_unit_count_of_a_sequential_write(u64::try_from(length_in_bytes).expect("内容长度"))
}

/// 第一个事务之后在同一个实例里发一次顺序写，错误原样交回。
fn try_sequential_write(
    pool: &mut BuiltPool,
    content: &[u8],
) -> Result<TransactionOutput, PublishError> {
    let previous = pool.output.clone();
    let parameters = parameters();
    let devices = pool.devices.as_mut().expect("镜像还开着");
    let mut writer = PoolWriter::new(&parameters, devices.as_mut_slice());
    publish_sequential_write(
        &mut writer,
        &mut pool.allocator,
        &previous,
        FirstFile {
            content,
            write_time_seconds: FIXED_WRITE_TIME_SECONDS + 60,
        },
        InstanceGeneration(1),
    )
}

/// 第一个事务之后在同一个实例里覆盖写一次（对照臂）。
fn try_overwrite(pool: &mut BuiltPool, content: &[u8]) -> Result<TransactionOutput, PublishError> {
    let previous = pool.output.clone();
    let parameters = parameters();
    let devices = pool.devices.as_mut().expect("镜像还开着");
    let mut writer = PoolWriter::new(&parameters, devices.as_mut_slice());
    publish_overwrite(
        &mut writer,
        &mut pool.allocator,
        &previous,
        FirstFile {
            content,
            write_time_seconds: FIXED_WRITE_TIME_SECONDS + 60,
        },
        InstanceGeneration(1),
    )
}

/// 这次发布在录制流里发出的那几步（带内容）。
fn operations_since(pool: &BuiltPool, first_operation: usize) -> Vec<RetainedOperation> {
    pool.retained_operations()[first_operation..].to_vec()
}

/// 只要一个数据单元的顺序写，与同内容的覆盖写写出的字节一个不差：同一条发布路径
/// （`.claude/rules/fs-design.md`「一个事务层，所有结构共用」——并行线一不许另开一条发布路径）。
#[test]
fn a_sequential_write_of_one_data_unit_writes_the_same_bytes_as_an_overwrite_of_the_same_content() {
    let content = content_of(4100);
    assert_eq!(data_units_for(content.len()), 1);

    let mut sequential_pool = build_pool("parallel-line-one-sequential");
    let sequential_first_operation = sequential_pool.stream.operations().len();
    let sequential = try_sequential_write(&mut sequential_pool, &content).expect("顺序写");

    let mut overwrite_pool = build_pool("parallel-line-one-overwrite");
    let overwrite_first_operation = overwrite_pool.stream.operations().len();
    let overwritten = try_overwrite(&mut overwrite_pool, &content).expect("覆盖写");

    assert_eq!(
        sequential.units, overwritten.units,
        "九个角色的单元字节相同"
    );
    assert_eq!(
        sequential.record_bytes, overwritten.record_bytes,
        "journal 记录逐字节相同：一个数据单元一个事务一条记录"
    );
    assert_eq!(sequential.root, overwritten.root, "根记录相同");
    assert_eq!(
        sequential.allocation_records, overwritten.allocation_records,
        "分配记录相同：落点按 D3（空间分配） 已定项 8 逐单元取最低空槽对"
    );
    assert_eq!(sequential.mapping_keys, overwritten.mapping_keys);
    assert_eq!(
        sequential.key_order_mismatches, 0,
        "一个单元的请求没有相邻 key 可比（C319（请求内单元按 key 升序发出没有条款也没有检查））"
    );
    assert_eq!(
        operations_since(&sequential_pool, sequential_first_operation),
        operations_since(&overwrite_pool, overwrite_first_operation),
        "录制流这一段逐步相同：写的落点、字节、屏障次序都一样"
    );
}

/// 切出的事务多于一个 ⇒ 在任何落盘动作之前被拒：错误成员带切分算出的单元数与两条没定的条款，
/// 盘上逐字节不变（系统配置槽、根环里的根、录制流步数），分配器的记录一条都没动。
#[test]
fn a_sequential_write_that_needs_two_data_units_is_refused_before_any_write_and_names_both_undecided_clauses(
) {
    assert_eq!(data_unit_payload_capacity(), 32_634);
    let content = content_of(32_635);
    assert_eq!(data_units_for(content.len()), 2);

    let mut pool = build_pool("parallel-line-one-two-units");
    let records_before = pool.allocator.records().to_vec();
    let before = disk_snapshot(&pool.memory_pool(), &pool.stream);

    let refusal = try_sequential_write(&mut pool, &content);

    match refusal {
        Err(PublishError::MoreThanOneDataUnitNeedsUndecidedClauses {
            data_units,
            undecided,
        }) => {
            assert_eq!(data_units, 2, "32635 字节要两个单元、两个事务、两条记录");
            assert_eq!(
                undecided,
                &UndecidedClauseBlockingMoreThanOneDataUnit::STILL_UNDECIDED_TODAY,
                "两条条款今天都没定：extent key 的 offset 单位、共享提交内生块在哪条记录里点名"
            );
        }
        other => panic!("要的是多单元被拒，拿到 {other:?}"),
    }

    let after: DiskSnapshot = disk_snapshot(&pool.memory_pool(), &pool.stream);
    assert_eq!(
        before, after,
        "盘上逐字节不变：系统配置槽、根环里的根、录制流步数（一个写、一道屏障都没发）"
    );
    assert_eq!(
        pool.allocator.records(),
        &records_before[..],
        "分配器一条记录都没动：拒在释放与分配之前"
    );
}

/// 单元数跨过 67（一条 journal 记录的点名项上限）与 144（一片 extent 叶装得下的记录数）两个门槛时，
/// 交回的单元数就是切分算出的那个数——两个门槛上都仍然是「在写之前拒绝」，不是走到一半才发现。
#[test]
fn the_refusal_reports_the_unit_count_the_split_computed_across_the_sixty_seven_and_one_hundred_forty_four_thresholds(
) {
    let payload_capacity = data_unit_payload_capacity();
    for expected_data_units in [2usize, 67, 68, 144, 145] {
        let content = content_of((expected_data_units - 1) * payload_capacity + 1);
        let expected_data_units = u64::try_from(expected_data_units).expect("单元数");
        assert_eq!(
            u64::try_from(
                split_sequential_write_into_one_unit_transactions(
                    u64::try_from(content.len()).expect("内容长度"),
                    1
                )
                .len()
            )
            .expect("事务数"),
            expected_data_units,
            "切分算出的事务数 = 单元数"
        );

        let mut pool = build_pool("parallel-line-one-thresholds");
        let before = disk_snapshot(&pool.memory_pool(), &pool.stream);
        let refusal = try_sequential_write(&mut pool, &content);
        match refusal {
            Err(PublishError::MoreThanOneDataUnitNeedsUndecidedClauses { data_units, .. }) => {
                assert_eq!(
                    data_units, expected_data_units,
                    "交回的单元数就是切分算出的那个"
                );
            }
            other => panic!("{expected_data_units} 个单元那一档要的是被拒，拿到 {other:?}"),
        }
        let after = disk_snapshot(&pool.memory_pool(), &pool.stream);
        assert_eq!(before, after, "每一档都在写之前拒绝，盘上逐字节不变");
    }
}
