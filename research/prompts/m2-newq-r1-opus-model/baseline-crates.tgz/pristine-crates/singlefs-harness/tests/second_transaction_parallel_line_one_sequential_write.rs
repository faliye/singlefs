//! 里程碑「第二个事务」并行线一（一个文件跨多个单元）的写路径：`publish_sequential_write` 按切分纪律
//! 把一次写请求切成若干一单元事务（D16（发布语义） 已定项 5 末段 + D23（journal 的角色与格式） 已定项 7），
//! 切出一个事务的那一档接在 `publish_overwrite` 上、写出的字节一个不变。
//!
//! **切出多于一个事务的那一档今天一律被拒**：extent 叶记录 key 的 offset 段取文件字节偏移还是单元序号、
//! 以及一次发布里多个数据单元怎么排，两条条款仓里都还没定
//! （`UndecidedClauseBlockingMoreThanOneDataUnit::STILL_UNDECIDED_TODAY`）。按
//! `.claude/agents/implementation-writer.md`「做什么」第 6 步，这种「走得到、而条款没写」的分支在**任何落盘动作之前**
//! 返回一个说清是哪条条款没定的错误成员，并由本文件钉住「返回这个成员、盘上逐字节不变」。
//!
//! 净荷容量 32634 字节（32768 − 头 105 − 预留 29，字节表二）是这两档的分界：32634 走得通、32635 被拒。
//! 那个数本身由 `singlefs-core` 的 `write_request_split` 单测钉着，这里只钉端到端的两档。

mod common;

use common::{build_pool, disk_snapshot, parameters, BuiltPool, FIXED_WRITE_TIME_SECONDS};
use singlefs_core::address::InstanceGeneration;
use singlefs_core::transaction::{
    publish_sequential_write, FirstFile, PoolWriter, PublishError,
    UndecidedClauseBlockingMoreThanOneDataUnit,
};
use singlefs_core::write_request_split::data_unit_count_of_a_sequential_write;

/// 净荷容量：一个数据单元装得下的文件字节数。两档的分界就在它上面。
const PAYLOAD_CAPACITY_IN_BYTES: usize = 32_634;

fn sequential_write(pool: &mut BuiltPool, content: &[u8]) -> Result<(), PublishError> {
    let publish_parameters = parameters();
    let devices = pool.devices.as_mut().expect("镜像还开着");
    let mut writer = PoolWriter::new(&publish_parameters, devices.as_mut_slice());
    let previous = pool.output.clone();
    let output = publish_sequential_write(
        &mut writer,
        &mut pool.allocator,
        &previous,
        FirstFile {
            content,
            write_time_seconds: FIXED_WRITE_TIME_SECONDS + 60,
        },
        InstanceGeneration(1),
    )?;
    pool.output = output;
    Ok(())
}

/// 一个单元装得下的顺序写走得通：切出一个事务，接在 `publish_overwrite` 那一路上。
#[test]
fn a_sequential_write_that_fits_one_data_unit_publishes_through_the_single_transaction_path() {
    let mut pool = build_pool("parallel-line-one-one-unit");
    assert_eq!(
        data_unit_count_of_a_sequential_write(PAYLOAD_CAPACITY_IN_BYTES as u64),
        1,
        "净荷容量整整一个单元：切分纪律切出一个事务"
    );

    let txg_before = pool.output.root.checkpoint_txg;
    sequential_write(&mut pool, &vec![7u8; PAYLOAD_CAPACITY_IN_BYTES]).expect("一个单元的顺序写");

    assert_eq!(
        pool.output.root.checkpoint_txg.0,
        txg_before.0 + 1,
        "一个事务一次发布：txg 加一"
    );
}

/// 多于一个单元的顺序写在**任何落盘动作之前**被拒，盘上逐字节不变，而且说清是哪两条条款没定。
#[test]
fn a_sequential_write_needing_two_data_units_is_refused_before_anything_reaches_the_disk() {
    let mut pool = build_pool("parallel-line-one-two-units");
    let content = vec![7u8; PAYLOAD_CAPACITY_IN_BYTES + 1];
    assert_eq!(
        data_unit_count_of_a_sequential_write(content.len() as u64),
        2,
        "净荷容量加一个字节：切分纪律切出两个事务"
    );

    let before = disk_snapshot(&pool.memory_pool(), &pool.stream);
    let refusal = sequential_write(&mut pool, &content).expect_err("两个单元今天一律被拒");

    let PublishError::MoreThanOneDataUnitNeedsUndecidedClauses {
        data_units,
        undecided,
    } = refusal
    else {
        panic!("该报「多单元要的条款没定」，实际 {refusal:?}");
    };
    {
        assert_eq!(data_units, 2, "报出要几个单元");
        assert!(
            undecided
                .contains(&UndecidedClauseBlockingMoreThanOneDataUnit::ExtentLeafKeyOffsetUnit),
            "错误成员要说清 extent 叶 key 的 offset 单位这一条还没定：{undecided:?}"
        );
        assert!(
            !undecided.is_empty(),
            "没定的条款一条都列不出来，这个成员就没有说清任何东西"
        );
    }

    let after = disk_snapshot(&pool.memory_pool(), &pool.stream);
    assert!(
        after == before,
        "盘上逐字节不变：系统配置槽、根环里的根、录制流步数都没动"
    );
}
